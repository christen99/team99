 const form = document.forms.iconForm;

const getForm = function() {
    let formBody = {}; 
for (let i = 0; i < form.elements.length; i++ ) {
        let el = form.elements[i];
    

let iconForm = form.nextElementSibling;
let select = form.// ????? спросить у учителя 

// console.log(select);

const getIcon = function () {
    let getForm = {};
       // ask ur teacher 
}

